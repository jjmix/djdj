=== 胖鼠采集(Fat Rat Collect) 微信知乎简书腾讯新闻头条采集, 自动采集自动发布, 开源插件 ===
Contributors: Fat Rat
Donate link: http://www.fatrat.cn/bounty
Tags: 采集, pangshu, 文章采集, 文章采集插件, 公众号文章采集, AutoTags, 自动发布, 文章定时爬取和发布, seo, 免费采集
Requires at least: 4.6
Tested up to: 5.2.1
Stable tag: 1.10.4
Requires PHP: 5.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

胖鼠采集(Fat Rat Collect) 是一款能够帮助你网站自动化文章采集的工具.自动采集(Auto Spider),自动发布(Auto Published),自动打标签(Auto Tags),节省精力,开源免费,胖鼠定时功能让你,省心省力. 胖鼠采集初始化配置例子有: 微信 简书 御龙在天 寻仙 心理咨询师 虎扑 直播8, 支持爬取任意网站列表详情页面 如(头条, 腾讯新闻, 简书, 知乎 ...) 去享受吧!
插件推荐：Instant Images、Smartideo、Clipboard Images

== Description ==
胖鼠采集(<a href="http://www.fatrat.cn" target="_blank">Fat Rat Collect</a>) 是一款能帮助你网站文章采集自动化的好帮手. 开源免费, 支持所有网站列表详情页面 它有列表批量自动采集,自动发布,自动打标签,等黑科技功能, 一次创建规则, 后续省心省力. 默认送给大家初始化配置例子有: 微信 简书 御龙在天 寻仙 心理咨询师 虎扑 直播8, 还可以采集(腾讯新闻, 简书, 知乎 ...) 去享受吧!

= 神奇之处 =
* 微信公众号文章采集 - 强大的Jquery可以处理各种内容, 纵享丝滑.
* 简书文章采集 - 强大的Jquery可以处理各种内容, 纵享丝滑.
* (独家主打) 列表页面文章批量采集 - 新开站点没内容, 胖鼠来帮你, 轻轻一点. 数不清的文章就来了.
* (独家主打) 详情页面文章采集 - 任何网站一秒搞定
* (独家主打) <a href="http://www.fatrat.cn/fatrat/260.html" target="_blank">分页爬取</a> - 历史数据, 也不放过. 一网打尽
* (胖鼠主打) 自动采集 - 安装上胖鼠的一刻, 已贴心为您自动开启, 不放过每一份数据
* (胖鼠主打) 自动发布 - SEO好帮手
* (独家主打) 调试模式 - 自建规则好帮手 调试BUG好帮手.
* (独家主打) 爬虫例子 - 点击安装例子, 一秒体验胖鼠.
* (主打主打) 文章自动添加动态内容 优化SEO.
* (独家独家) 站群需求 - 支持.
* (独家独家) 自动打标签 <a href="http://www.fatrat.cn/fatrat/220.html" target="_blank">Auto Tags</a> - 支持.
* (胖鼠采集) 文章过滤 - 支持.
* (胖鼠采集) 批量导入数据 - 支持.
* (胖鼠采集) 自动特色图片 - 支持.
* (胖鼠采集) 内容区域自动增加动态数据 <a href="http://www.fatrat.cn/fatrat/229.html" target="_blank">Dynamic Content</a> SEO最爱
* (胖鼠采集) 采集图片加入媒体库 - 支持.
* (胖鼠采集) 数据处理 - 完美支持Html Jquery
* (胖鼠采集) 内容关键字过滤替换 伪原创 - 支持.
* (胖鼠采集) 自定义采集任何网站 - 完美支持.
* (胖鼠采集) 自定义文章图片链接类型 - 支持.
* (重磅重磅) 胖鼠采集完全基于Wordpress. 安装即用,Github开源作品
* (解答疑惑) 胖鼠采集2018年12月30日上线, 需要大家多多支持.
* (声明声明) 如你的PHP版本小于PHP7, 请移步胖鼠采集的Github下载使用胖鼠v5版本 分支名: based_php_5.6
* (声明声明) 胖鼠采集初衷为参考学习交流; 请大家遵纪守法. 抵制违法犯罪.
* (声明声明) 胖鼠采集开源可供您查阅代码, 或者二次开发等其他操作.
* 推荐优秀插件: pangshu,fatrat,fatratcollect,pangshucaiji,collect,baidu,seo,keyword,description,jianshu,weixin,wechat,jinritoutiao,taobaoke,huochetou,houyicaiji,shenjian,csdn,cnblogs,wenzhang,gongzhonghao,plugin,Github,WPJAM,bazhuayu,locoy,WP-AutoPost(WP-AutoBlog),mifeng,WP-Jpost,BeePress,qiniu,bokeyuan,oss,cdn,caiji,sitemap,WordPress HTTPS (SSL),wp encrypt,really simple ssl,wp-super-cache,WP Rocket,All-in-One SEO Pack,login LockDown,Comments Link Redirect,Add Post URL,BackWPup,DX-auto-publish,Link Manager,No Category Parents,Platinum SEO Pack,WP Keyword Link,Yet Another Related Posts Plugin,Fix image width,Role Manager,Search & Replace,WordPress Database Backup,WP-PostViews,WP PHP widget,Baidu Sitemap Generator,DB Cache Reloaded Fix + Hyper Cache,SEO Friendly Images,BackWPup,Simple URLs,Redirection,Contact Form 7

= 胖鼠采集系统架构 =
* 系统分为三大块.
* ① 爬虫模块, 先锋 配置模块的各种特色配置来猎取数据.
* ② 配置模块, 支撑 爬虫模块为他提供采集规则核心能量.
* ③ 数据模块, 数据 此模块拥有胖鼠各种特色发布功能.

= 使用谨记 =
* 如果你的PHP版本小于PHP7, 请移步胖鼠采集的Github下载使用胖鼠v5版本 分支名: based_php_5.6
* 工具新版本刚上线. 如果遇到不懂的. 别着急. 看看例子慢慢来.
* 本工具仅供学习参考, 作者不承担任何风险. 不同意请自觉卸载!
* 本工具仅供学习参考, 作者不承担任何风险. 不同意请自觉卸载!
* 本工具仅供学习参考, 作者不承担任何风险. 不同意请自觉卸载!

== Installation ==

安装：
1. 在插件中搜索 <strong>胖鼠采集</strong> 安装即可
2. 将插件文件上传到/wp-content/plugins/目录 即可
3. 如果你的PHP版本小于PHP7, 请去胖鼠采集的Github下载使用胖鼠v5版本 分支名: based_php_5.6

== Frequently Asked Questions ==

= 胖鼠FAQ =
采集成功 提示ok! 但是没有数据?
可能是乱码问题. 非utf-8页面 可能会出现自动转码失败.乱码了

= 关于新建配置 =
请多多使用debug功能
作者在写配置的时候也会先用debug功能调试


= 胖鼠推荐服务环境 =
推荐 使用php7以上版本
推荐 保持胖鼠最新版，新版本
胖鼠Q群: 454049736

== Screenshots ==
1. 胖鼠强大的爬虫中心
2. 支撑胖鼠的配置中心。
3. 发布文章的数据中心。
4. 自定义任意网站规则,各种贴心小提示,为你保驾护航。

== Changelog ==
= 1.10.4 = 2019-06-12
* 优化一些地方

= 1.10.3 = 2019-05-19
* 优化 Dynamic Content 功能, 优化了取文字样式
* 优化 Auto Tags 功能, 暂时去掉了标签追加链接功能, 有bug回头解决了再加
* 数据中心弱网发布时间优化

= 1.10.2 = 2019-05-05
* 优化 Dynamic Content 功能
* 优化 Auto Tags 功能
* Auto Tags 功能 增加开关和一些优化

= 1.10.1 = 2019-05-04
* 代码优化

= 1.10.0 = 2019-05-04
* 新功能 Dynamic Content

= 1.9.0 = 2019-05-03
* 新功能 Auto Tags 文章自动打Tag or 优化一些文案

= 1.8.7 = 2019-04-30
* 修复一个紧急bug

= 1.8.6 = 2019-04-29
* 文章滤重改为强滤重
* 数据表增加一项字段
* 一次发布最大数量增加到30

= 1.8.4 = 2019-04-23
* 优化 据个别鼠要求, 采集标题 增长为120个汉字
* 优化 采集保存配置一点逻辑优化
* 文案优化

= 1.8.3 = 2019-04-15
* 优化 采集标题可能超过40个汉字长度 控制在40个字符之内
* 优化 下载图片可能会超时优化了连接时间
* 优化 一次发布很多篇, 极端情况可能图片超时问题
* 优化 发布文章个别情况可能出现报错, 捕获错误
* 优化 文章别名, 使用文章标题作为文章别名
* 新增 公告功能: 用于胖鼠紧急通知众鼠使用, 无风险。
* 新增 微信增加 作者变量{author} 公众号名字变量{name} 简书增加作者变量{author}

= 1.8.2 = 2019-04-14
* 修复了 一个不影响大局的sql错误

= 1.8.1 = 2019-04-14
* 修复 微信 简书 采集失败bug

= 1.8.0 = 2019-04-14
* 胖鼠采集全新架构
* window主机用户采集微信图片 鼠友服务器CA证书验证不通过问题
* window主机 路径 DIRECTORY_SEPARATOR 可能出现的bug
* 采集内核2.0。更快的采集速度。 (3.0规划已有。采集速度会超级超级快)
* 采集图片自动查找后缀算法优化
* 自动特色图片功能完成
* 图片加入媒体库功能
* 图片加入附件
* 发布时图片发布失败。补二次下载

= 1.7.5 = 2019-04-09
* 修复了几位鼠友用window服务器出现的图片路径乱码bug

= 1.7.4 = 2019-03-31
* 修复了简书图片bug
* 数据中心增加数据统计功能

= 1.7.3 = 2019-03-08
* 冒泡

= 1.7.2 = 2019-02-25
* 修复群里一个鼠友采集图片失败的bug.
* 升级群里鼠友采集的图片默认居中需求.

= 1.7.1 = 2019-02-15
* 胖鼠采集PHP v5.6 版本尝鲜版发布.
* 优化一些文案.

= 1.7.0 = 2019-01-25
* 定时发布 (给鼠友增加开关）
* 定时采集 (给鼠友增加开关）
* 图片可设置使用 相对/绝对 路径. 站群/单站点/CDN可能要的需求
* 微信采集自定义内容(鼠友要求可增加来源)
* 免责声明

= 1.6.3 = 2019-01-24
* 鼠友发现采集的微信视频无法播放BUG!

= 1.6.2 = 2019-01-22
* 微信 And 列表采集 图片 自动剔除多余属性 增加 Alt字段 值为title 更好的SEO!

= 1.6.1 = 2019-01-21
* 一个安全过滤误伤了鼠友. 已修复
* 版本号修正

= 1.6.0 = 2019-01-20
* Php版本验证提示
* 配置中心批量删除
* 数据中心可能出现的一个notice错误
* 数据发布,增加发布作者,文章状态.
* 数据中心作者字段优化
* 赞赏码

= 1.5.1 = 2019-01-15
* 帮助的a 标签跳转新开标签页
* 增加自动发布tag页面
* 新增加的文档的链接
* 分页采集增加默认select
* 修复自动爬去功能异常
* Css Js样式 兼容了其他插件
* 修复一个列表爬虫。由于目标站不统一。链接可能拼接错误bug

= 1.5.0 = 2019-01-13 11:16
* 优化配置中心一个 notice 错误
* 增加了数据批量删除
* 增加数据批量发布
* 文章增加发布分类
* 使用权限增加作者 编辑 管理员

= 1.4.3 = 2019-01-03 10:39
* ok 优化了详情爬虫, 增加了默认选项
* ok 增加了几个采集配置 寻仙新闻 御龙在天新闻 心理咨询师新闻 直播吧详情 虎扑详情
* ok 优化了前端错误提示
* 有个个别网站 gbk 个别乱码问题/未解决。utf-8很稳定
* 今天关闭了站群自动发布,自动发布什么时候再次开启?

= 1.4.2 = 2019-01-02
* 暂时去掉站群发布页面
* 去掉了一些默认配置规则，后续增加
* 采集url地址 代码优化

= 1.4.1 = 2019-01-01 11:05
* 增加了小提示功能.等你发现在哪里.
* 增加了简书采集
* 捕获简书新的图片src, 调整了代码

= 1.4.0 = 2018-12-30 03:09
* 跳几个小版本, 因为这次是一个架构稳定版本(稳)
* 新增自定义详情爬取
* 自动识别 img (src or data-src)
* 配置页面优化 注释优化 服务端优化
* 发布中心优化服务端 页面优化
* 爬虫中心 服务端优化 前端优化
* 前端ajax交互优化
* 数据库优化了表，增加了索引
* 优化掉了Log表
* ...

= 1.0.0 = 2018-12-20
* 胖鼠第一个版本上线了 不写了 具体的功能了 信息量有点大。大家自己安装感受一下具体功能吧。

== Upgrade Notice ==

